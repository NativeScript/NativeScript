document.write("Hello from main.ts !");

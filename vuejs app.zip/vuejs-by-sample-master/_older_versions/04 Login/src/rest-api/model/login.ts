export interface LoginEntity {
  login: string;
  password: string;
}

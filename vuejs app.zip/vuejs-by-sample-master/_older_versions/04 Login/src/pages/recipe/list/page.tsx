import Vue, { VNode } from 'vue';

export const RecipeListPage = Vue.extend({
  render(h): VNode {
    return (
      <h1>Recipe List Page</h1>
    );
  },
});

import Vue from 'vue';

new Vue({
  el: '#root',
  template: '<h1>{{message}}</h1>',
  data: {
    message: 'Hello from Vue.js',
  },
});

import EditRecipePage from './Page.vue';
export { EditRecipePage };

<template>
  <thead>
    <th>Name</th>
    <th>Description</th>
    <th></th>
  </thead>
</template>

<script lang="ts">
import Vue from "vue";

export default Vue.extend({
  name: "HeaderComponent"
});
</script>

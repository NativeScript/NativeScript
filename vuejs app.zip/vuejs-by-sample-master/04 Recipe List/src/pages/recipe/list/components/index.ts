import TableComponent from './Table.vue';
import SearchBarComponent from './SearchBar.vue';

export { TableComponent, SearchBarComponent };

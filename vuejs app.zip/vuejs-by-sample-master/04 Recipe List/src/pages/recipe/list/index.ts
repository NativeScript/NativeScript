import RecipeListPageContainer from './PageContainer.vue';

export { RecipeListPageContainer };

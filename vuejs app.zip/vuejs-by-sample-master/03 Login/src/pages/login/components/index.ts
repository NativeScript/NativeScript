import FormComponent from './Form.vue';

export { FormComponent };

<template>
  <h1>Recipe List Page</h1>
</template>

<script lang="ts">
import Vue from "vue";

export default Vue.extend({
  name: "RecipeListPage"
});
</script>

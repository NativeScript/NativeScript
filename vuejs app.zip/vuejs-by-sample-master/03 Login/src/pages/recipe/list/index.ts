import RecipeListPage from './Page.vue';

export { RecipeListPage };

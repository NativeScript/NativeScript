export interface Login {
  name: string;
  password: string;
}
